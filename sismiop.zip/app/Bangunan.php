<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bangunan extends Model
{
    protected $table = 'kuesionerbangunan';
    protected $primaryKey = 'id';
    protected $fillable = [];
}
