<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TanahHias extends Model
{
    protected $table = 'tanah_hias';
    protected $primaryKey = 'thias_id';

    protected $fillable = [];
}
